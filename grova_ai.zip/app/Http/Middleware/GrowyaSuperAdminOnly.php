<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class GrowyaSuperAdminOnly
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless($request->user() && $request->user()->hasRole('super_admin'), 403);
        return $next($request);
    }
}

<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;


Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');


\Illuminate\Support\Facades\Schedule::command(
    'growya:send-reminders'
)->dailyAt('09:00')->withoutOverlapping();


Schedule::command('growya:crm-sync --limit=20000')
    ->hourly()
    ->withoutOverlapping();

Schedule::command('growya:crm-reminders')
    ->dailyAt('09:15')
    ->withoutOverlapping();

<?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('growya-ui/utilities.css')); ?>?v=20261013">
<?php echo $__env->make('partials.growya-assets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/public/partials/assets.blade.php ENDPATH**/ ?>
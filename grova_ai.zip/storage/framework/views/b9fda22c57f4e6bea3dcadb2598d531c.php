<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null, 'business' => null, 'workspaceRole' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null, 'business' => null, 'workspaceRole' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body class="g-app">
    <?php
        $sidebarUser = auth()->user();
        $isSuperAdmin = $sidebarUser->hasRole('super_admin', 'web');
        $sidebarBusiness = $business ?? request()->route('business');

        if ($sidebarBusiness && !($sidebarBusiness instanceof \App\Models\Business)) {
            $sidebarBusiness = \App\Models\Business::find($sidebarBusiness);
        }

        $access = app(\App\Services\BusinessAccessService::class);
        $isBusinessOwner = $sidebarBusiness && (int) $sidebarBusiness->owner_id === (int) $sidebarUser->id;
        $sidebarMembership = $sidebarBusiness ? $access->membership($sidebarUser, $sidebarBusiness) : null;
        $hasBusinessAccess = $sidebarBusiness && ($isSuperAdmin || $isBusinessOwner || $sidebarMembership);

        $sidebarRole = $isSuperAdmin
            ? 'Super Admin'
            : $workspaceRole ??
                ($isBusinessOwner ? 'Business Owner' : ($sidebarMembership ? 'Business Admin' : 'Customer'));

        $businessMenu = [
            ['Overview', 'businesses.show', 'store', 'business.view'],
            ['Customer CRM', 'growya.crm.index', 'users', 'business.view'],
            ['Lead Insights', 'growya.lead-insights.owner', 'grid', 'business.view'],
            ['Customer messages', 'growya.chat.inbox', 'chat', 'chats.view'],
            ['KYC & Documents', 'growya.kyc.owner', 'shield', 'business.view'],
            ['Subscription billing', 'growya.billing.owner', 'wallet', 'business.view'],
            ['Analytics & Reports', 'growya.analytics.owner', 'grid', 'business.view'],
            ['Coupons & Discounts', 'businesses.coupons.index', 'tag', 'business.update'],
            ['Plan usage', 'growya.entitlements.usage', 'chart', 'business.view'],
            ['Subscription plans', 'growya.subscriptions.business', 'wallet', 'business.view'],
            ['Map Location', 'growya.nearby.location.edit', 'pin', 'business.update'],
            ['Paid promotions', 'growya.promotions.owner', 'tag', 'business.view'],
            ['Products', 'businesses.products.index', 'box', 'products.view'],
            ['Services', 'businesses.services.index', 'sparkles', 'services.view'],
            ['Orders', 'businesses.orders.index', 'bag', 'products.view'],
            ['Payments', 'businesses.payments.index', 'wallet', 'products.view'],
            ['Returns & refunds', 'businesses.returns.index', 'return', 'products.view'],
            ['Delivery management', 'businesses.delivery.index', 'truck', 'products.view'],
            ['Product enquiries', 'businesses.product-enquiries.index', 'chat', 'products.view'],
            ['Service enquiries', 'businesses.service-enquiries.index', 'chat', 'services.view'],
            ['Appointments', 'businesses.appointments.index', 'calendar', 'services.view'],
            ['Offers & promotions', 'businesses.offers.index', 'tag', 'services.view'],
            ['Gallery', 'businesses.gallery.index', 'photo', 'services.view'],
            ['Reviews', 'businesses.reviews.index', 'star', 'services.view'],
            ['Business hours', 'businesses.hours.index', 'clock', 'business.view'],
            ['Social links', 'businesses.social-links.index', 'link', 'business.view'],
        ];

        $adminMenu = [
            ['Business approvals', 'admin.business-verifications.index', 'admin.business-verifications.*', 'shield'],
            ['All businesses', 'businesses.index', 'businesses.index', 'store'],
            ['Lead Insights', 'growya.lead-insights.admin', 'growya.lead-insights.admin*', 'grid'],
            ['Referrals & Rewards', 'growya.referrals.admin', 'growya.referrals.admin', 'users'],
            ['Subscription billing', 'growya.billing.admin', 'growya.billing.admin', 'wallet'],
            ['Chat moderation', 'growya.chat.reports', 'growya.chat.reports*', 'shield'],
            ['Business claims', 'growya.claims.admin', 'growya.claims.admin*', 'shield'],
            ['Business KYC Reviews', 'growya.kyc.admin', 'growya.kyc.admin*', 'shield'],
            ['Analytics & Reports', 'growya.analytics.admin', 'growya.analytics.admin*', 'grid'],
            ['Users', 'users.index', 'users.*', 'users'],
            ['User roles', 'growya.users.roles.index', 'growya.users.roles.*', 'users'],
            ['Access control', 'growya.roles.matrix', 'growya.roles.matrix*', 'shield'],
            ['Roles', 'roles.index', 'roles.*', 'grid'],
            ['Permissions', 'permissions.index', 'permissions.*', 'shield'],
            ['Ownership transfers', 'growya.ownership.index', 'growya.ownership.*', 'return'],
            ['Categories', 'categories.index', 'categories.*', 'grid'],
            ['Product tags', 'tags.index', 'tags.*', 'tag'],
            ['Product attributes', 'attributes.index', 'attributes.*', 'settings'],
            ['Promotion approvals', 'growya.promotions.admin', 'growya.promotions.*', 'star'],
            ['Promotion packages', 'growya.promotions.packages', 'growya.promotions.packages*', 'tag'],
            ['Manage plans', 'growya.plans.index', 'growya.plans.*', 'wallet'],
            ['Subscriptions', 'growya.subscriptions.admin', 'growya.subscriptions.*', 'bag'],
            ['Review moderation', 'admin.business-reviews.index', 'admin.business-reviews.*', 'star'],
        ];

        $isAccountSettings = request()->routeIs('profile.*', 'settings.*');
    ?>

    <a href="#main-content" class="g-skip">Skip to content</a>
    <div class="g-overlay" data-g-overlay hidden></div>

    <aside id="workspace-navigation" class="g-sidebar" data-g-sidebar aria-label="Workspace navigation">
        <a href="<?php echo e(route('dashboard')); ?>" class="g-brand" wire:navigate>
            <span class="g-brand-mark">g</span>growya<span class="g-brand-dot">.</span>
        </a>

        <button type="button" class="g-icon-button g-sidebar-close" data-g-menu-close aria-label="Close navigation">
            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'close']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
        </button>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasBusinessAccess): ?>
            <div class="g-sidebar-context">
                <small>CURRENT BUSINESS</small>
                <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'store']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'store']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                <?php echo e($sidebarBusiness->name); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebarUser->currentTeam): ?>
            <div class="g-sidebar-team">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('team-switcher', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3627245310-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


        
        
        <p class="g-sidebar-label">Workspace</p>
        <nav>
            <a class="g-nav-item <?php echo e(request()->routeIs('dashboard') ? 'is-current' : ''); ?>"
                href="<?php echo e(route('dashboard')); ?>" <?php if(request()->routeIs('dashboard')): ?> aria-current="page" <?php endif; ?>
                wire:navigate>
                <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'home']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Overview
            </a>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isSuperAdmin): ?>
                <a class="g-nav-item <?php echo e(request()->routeIs('businesses.index') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('businesses.index')); ?>" <?php if(request()->routeIs('businesses.index')): ?> aria-current="page" <?php endif; ?>
                    wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'store']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'store']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>My businesses
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <a class="g-nav-item <?php echo e(request()->routeIs('growya.notifications.*') ? 'is-current' : ''); ?>"
                href="<?php echo e(route('growya.notifications.index')); ?>"
                <?php if(request()->routeIs('growya.notifications.*')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'bell']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bell']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Notifications
            </a>


            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.reminders.preferences')): ?>
                <a class="g-nav-item <?php echo e(request()->routeIs('growya.reminders.preferences') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('growya.reminders.preferences')); ?>" wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clock']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                    Reminder Preferences
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.support.index')): ?>
                <a class="g-nav-item <?php echo e(request()->routeIs('growya.support.*') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('growya.support.index')); ?>"
                    <?php if(request()->routeIs('growya.support.*')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'chat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chat']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Support Tickets
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasBusinessAccess): ?>
            <p class="g-sidebar-label">Business management</p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebarBusiness->verification_status === 'approved'): ?>
                <nav>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $businessMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $routeName, $icon, $permission]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has($routeName) && $access->can($sidebarUser, $sidebarBusiness, $permission)): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($routeName !== 'growya.subscriptions.business' || $isSuperAdmin || $isBusinessOwner): ?>
                                <?php
                                    $current =
                                        request()->routeIs($routeName) ||
                                        (str_ends_with($routeName, '.index') &&
                                            request()->routeIs(substr($routeName, 0, -5) . '*'));
                                ?>
                                <a class="g-nav-item <?php echo e($current ? 'is-current' : ''); ?>"
                                    href="<?php echo e(route($routeName, $sidebarBusiness)); ?>"
                                    <?php if($current): ?> aria-current="page" <?php endif; ?> wire:navigate>
                                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => $icon]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?><?php echo e($label); ?>

                                </a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('businesses.wishlist.index') && ($isSuperAdmin || $isBusinessOwner)): ?>
                        <?php $wishlistCurrent = request()->routeIs('businesses.wishlist.*'); ?>
                        <a class="g-nav-item <?php echo e($wishlistCurrent ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('businesses.wishlist.index', $sidebarBusiness)); ?>"
                            <?php if($wishlistCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'heart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Wishlist leads
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSuperAdmin && Route::has('growya.plan-overrides.edit')): ?>
                        <?php $overrideActive = request()->routeIs('growya.plan-overrides.*'); ?>
                        <a class="g-nav-item <?php echo e($overrideActive ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('growya.plan-overrides.edit', $sidebarBusiness)); ?>"
                            <?php if($overrideActive): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'settings']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Custom plan limits
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($access->canManageStaff($sidebarUser, $sidebarBusiness)): ?>
                        <?php $staffCurrent = request()->routeIs('businesses.staff.*'); ?>
                        <a class="g-nav-item <?php echo e($staffCurrent ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('businesses.staff.index', $sidebarBusiness)); ?>"
                            <?php if($staffCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Staff management
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.crm.staff.dashboard')): ?>
                        <?php $staffCrmCurrent = request()->routeIs('growya.crm.staff.*'); ?>
                        <a class="g-nav-item <?php echo e($staffCrmCurrent ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('growya.crm.staff.dashboard', $sidebarBusiness)); ?>"
                            <?php if($staffCrmCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Staff CRM
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($sidebarBusiness) && $sidebarBusiness): ?>
                        <a class="g-nav-item <?php echo e(request()->routeIs('growya.crm.kanban.*') ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('growya.crm.kanban.index', ['business' => $sidebarBusiness->id])); ?>"
                            wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'grid']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                            CRM Kanban
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.crm.incentives.index')): ?>
                        <?php $incentivesCurrent = request()->routeIs('growya.crm.incentives.*'); ?>
                        <a class="g-nav-item <?php echo e($incentivesCurrent ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('growya.crm.incentives.index', $sidebarBusiness)); ?>"
                            <?php if($incentivesCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'wallet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wallet']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>CRM Incentives
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.finance.index') && ($isSuperAdmin || $isBusinessOwner)): ?>
                        <?php $financeCurrent = request()->routeIs('growya.finance.*'); ?>
                        <a class="g-nav-item <?php echo e($financeCurrent ? 'is-current' : ''); ?>"
                            href="<?php echo e(route('growya.finance.index', $sidebarBusiness)); ?>"
                            <?php if($financeCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'wallet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wallet']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Business Finance
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </nav>
            <?php else: ?>
                <p class="g-sidebar-note" style="padding: 0 1rem; font-size: .8rem; opacity: .7;">
                    Approval pending. Approve hone ke baad menu yahan dikhega.
                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSuperAdmin): ?>
            <p class="g-sidebar-label">Administration</p>
            <nav>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $adminMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $routeName, $active, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has($routeName)): ?>
                        <?php $adminCurrent = request()->routeIs($active); ?>
                        <a class="g-nav-item <?php echo e($adminCurrent ? 'is-current' : ''); ?>" href="<?php echo e(route($routeName)); ?>"
                            <?php if($adminCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                            <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => $icon]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?><?php echo e($label); ?>

                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.admin.wishlist.index')): ?>
                    <?php $adminWishlistCurrent = request()->routeIs('growya.admin.wishlist.*'); ?>
                    <a class="g-nav-item <?php echo e($adminWishlistCurrent ? 'is-current' : ''); ?>"
                        href="<?php echo e(route('growya.admin.wishlist.index')); ?>"
                        <?php if($adminWishlistCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'heart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Wishlist interests
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </nav>
        <?php else: ?>
            <p class="g-sidebar-label">Your marketplace</p>
            <nav>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.referrals.mine')): ?>
                    <a class="g-nav-item <?php echo e(request()->routeIs('growya.referrals.mine') ? 'is-current' : ''); ?>"
                        href="<?php echo e(route('growya.referrals.mine')); ?>" wire:navigate>
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                        My Referrals
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.chat.mine')): ?>
                    <?php $chatCurrent = request()->routeIs('growya.chat.mine', 'growya.chat.show'); ?>
                    <a class="g-nav-item <?php echo e($chatCurrent ? 'is-current' : ''); ?>"
                        href="<?php echo e(route('growya.chat.mine')); ?>"
                        <?php if($chatCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'chat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chat']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>My Messages
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.claims.mine')): ?>
                    <?php $claimsCurrent = request()->routeIs('growya.claims.mine', 'growya.claims.create'); ?>
                    <a class="g-nav-item <?php echo e($claimsCurrent ? 'is-current' : ''); ?>"
                        href="<?php echo e(route('growya.claims.mine')); ?>"
                        <?php if($claimsCurrent): ?> aria-current="page" <?php endif; ?> wire:navigate>
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'store']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'store']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>My business claims
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <a class="g-nav-item <?php echo e(request()->routeIs('growya.orders.*') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('growya.orders.mine')); ?>"
                    <?php if(request()->routeIs('growya.orders.*')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'bag']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bag']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>My orders
                </a>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.addresses.index')): ?>
                    <a class="g-nav-item <?php echo e(request()->routeIs('growya.addresses.*') ? 'is-current' : ''); ?>"
                        href="<?php echo e(route('growya.addresses.index')); ?>"
                        <?php if(request()->routeIs('growya.addresses.*')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'map-pin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'map-pin']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Manage addresses
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('growya.wishlist.mine')): ?>
                    <a class="g-nav-item <?php echo e(request()->routeIs('growya.wishlist.*') ? 'is-current' : ''); ?>"
                        href="<?php echo e(route('growya.wishlist.mine')); ?>"
                        <?php if(request()->routeIs('growya.wishlist.*')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'heart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>My wishlist
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <a class="g-nav-item <?php echo e(request()->routeIs('public.business.following') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('public.business.following')); ?>"
                    <?php if(request()->routeIs('public.business.following')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'heart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Following
                </a>

                <a class="g-nav-item <?php echo e(request()->routeIs('growya.business-request.*') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('growya.business-request.status')); ?>"
                    <?php if(request()->routeIs('growya.business-request.*')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'clock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clock']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Business applications
                </a>

                <a class="g-nav-item <?php echo e(request()->routeIs('businesses.create') ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('businesses.create')); ?>"
                    <?php if(request()->routeIs('businesses.create')): ?> aria-current="page" <?php endif; ?> wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'plus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Register a business
                </a>
            </nav>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="g-sidebar-foot">
            <nav>
                <a class="g-nav-item" href="<?php echo e(route('public.marketplace.index')); ?>">
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'globe']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'globe']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Explore marketplace
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'arrow-up-right','class' => 'ml-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-up-right','class' => 'ml-auto']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                </a>
                <a class="g-nav-item <?php echo e($isAccountSettings ? 'is-current' : ''); ?>"
                    href="<?php echo e(route('profile.edit')); ?>" <?php if($isAccountSettings): ?> aria-current="page" <?php endif; ?>
                    wire:navigate>
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'settings']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Account settings
                </a>
            </nav>

            <div class="g-sidebar-user">
                <span class="g-avatar"><?php echo e($sidebarUser->initials()); ?></span>
                <div>
                    <strong><?php echo e($sidebarUser->name); ?></strong>
                    <small><?php echo e($sidebarRole); ?></small>
                </div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" aria-label="Log out" title="Log out">
                        <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'logout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                    </button>
                </form>
            </div>
        </div>
    </aside>

    
    <div class="g-workspace">
        <header class="g-topbar">
            <div class="g-topbar-start">
                <button type="button" class="g-icon-button g-menu-toggle" data-g-menu-toggle aria-expanded="false"
                    aria-controls="workspace-navigation" aria-label="Open navigation">
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'menu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                </button>
                <div class="g-breadcrumb">
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'grid']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                    <span><?php echo e($sidebarRole); ?></span>
                    <span>/</span>
                    <strong><?php echo e($title ?? 'Workspace'); ?></strong>
                </div>
            </div>

            <div class="g-topbar-actions">
                <a class="g-topbar-search" href="<?php echo e(route('public.search.index')); ?>">
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Search marketplace
                </a>
                <span class="g-date"><?php echo e(now()->format('D, d M Y')); ?></span>
                <button type="button" class="g-icon-button" x-data
                    @click="$flux.appearance = $flux.dark ? 'light' : 'dark'" aria-label="Switch light or dark theme">
                    <?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'moon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'moon']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
                </button>
                <?php if (isset($component)) { $__componentOriginal26e7fa366fbe2aea9eb6ab86db1e7f70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26e7fa366fbe2aea9eb6ab86db1e7f70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya-live-notification-bell','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya-live-notification-bell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26e7fa366fbe2aea9eb6ab86db1e7f70)): ?>
<?php $attributes = $__attributesOriginal26e7fa366fbe2aea9eb6ab86db1e7f70; ?>
<?php unset($__attributesOriginal26e7fa366fbe2aea9eb6ab86db1e7f70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26e7fa366fbe2aea9eb6ab86db1e7f70)): ?>
<?php $component = $__componentOriginal26e7fa366fbe2aea9eb6ab86db1e7f70; ?>
<?php unset($__componentOriginal26e7fa366fbe2aea9eb6ab86db1e7f70); ?>
<?php endif; ?>
                <a href="<?php echo e(route('profile.edit')); ?>" class="g-avatar" aria-label="Account settings"
                    title="<?php echo e($sidebarUser->name); ?>" wire:navigate>
                    <?php echo e($sidebarUser->initials()); ?>

                </a>
            </div>
        </header>

        <main id="main-content">
            <?php echo e($slot); ?>

        </main>

        <footer class="g-workspace-footer">
            <span>© <?php echo e(date('Y')); ?> Growya. Built for local growth.</span>
            <a href="<?php echo e(route('home')); ?>">Visit website ↗</a>
        </footer>
    </div>

    <?php app("livewire")->forceAssetInjection(); ?><div x-persist="<?php echo e('toast'); ?>">
        <?php if (isset($component)) { $__componentOriginal9e52f305f7cdd22fd6be350cf248d973 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e52f305f7cdd22fd6be350cf248d973 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::toast.group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::toast.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

            <?php if (isset($component)) { $__componentOriginal6e0689304ed9fe6f1f826bea0820c41b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::toast.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b)): ?>
<?php $attributes = $__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b; ?>
<?php unset($__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e0689304ed9fe6f1f826bea0820c41b)): ?>
<?php $component = $__componentOriginal6e0689304ed9fe6f1f826bea0820c41b; ?>
<?php unset($__componentOriginal6e0689304ed9fe6f1f826bea0820c41b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e52f305f7cdd22fd6be350cf248d973)): ?>
<?php $attributes = $__attributesOriginal9e52f305f7cdd22fd6be350cf248d973; ?>
<?php unset($__attributesOriginal9e52f305f7cdd22fd6be350cf248d973); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e52f305f7cdd22fd6be350cf248d973)): ?>
<?php $component = $__componentOriginal9e52f305f7cdd22fd6be350cf248d973; ?>
<?php unset($__componentOriginal9e52f305f7cdd22fd6be350cf248d973); ?>
<?php endif; ?>
    </div>
    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body>

</html>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/layouts/app/sidebar.blade.php ENDPATH**/ ?>
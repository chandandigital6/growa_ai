<?php if (isset($component)) { $__componentOriginal08b8a564843783787e0bee3357e24f38 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal08b8a564843783787e0bee3357e24f38 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::auth','data' => ['title' => __('Log in')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Log in'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <h1>Welcome back.</h1><p class="mt-2 text-sm text-slate-500">Your next discovery starts here.</p>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?><div role="status" class="g-alert g-tone-green mt-5"><?php echo e(session('status')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?><div role="alert" id="login-errors" class="g-alert g-tone-rose mt-5"><?php echo e($errors->first()); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <form method="POST" action="<?php echo e(route('login.store')); ?>" class="mt-7 space-y-5"><?php echo csrf_field(); ?>
        <div><label for="email" class="mb-2 block">Email address</label><input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="email" placeholder="you@example.com" <?php if($errors->has('email')): ?> aria-invalid="true" aria-describedby="login-errors" <?php endif; ?> class="w-full border bg-white px-4 py-3 text-slate-900 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/15"></div>
        <div><div class="mb-2 flex items-center justify-between gap-2"><label for="password">Password</label><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('password.request')): ?><a href="<?php echo e(route('password.request')); ?>" class="text-xs font-semibold text-emerald-700">Forgot password?</a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div><div class="g-password"><input id="password" name="password" type="password" required autocomplete="current-password" placeholder="Enter your password" class="w-full border bg-white px-4 py-3 text-slate-900 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/15"><button type="button" class="g-password-toggle" data-g-password-toggle aria-controls="password" aria-pressed="false">Show</button></div></div>
        <label class="flex items-center gap-2 text-slate-600"><input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?> class="rounded border-slate-300 text-emerald-600 focus:ring-emerald-600">Keep me signed in</label>
        <button type="submit" class="g-btn g-btn-primary w-full" data-test="login-button">Log in to Growya<?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?></button>
    </form>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('register')): ?><p class="mt-7 text-center text-xs text-slate-600">New around here? <a href="<?php echo e(route('register')); ?>" class="font-semibold text-emerald-700">Create an account</a></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal08b8a564843783787e0bee3357e24f38)): ?>
<?php $attributes = $__attributesOriginal08b8a564843783787e0bee3357e24f38; ?>
<?php unset($__attributesOriginal08b8a564843783787e0bee3357e24f38); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08b8a564843783787e0bee3357e24f38)): ?>
<?php $component = $__componentOriginal08b8a564843783787e0bee3357e24f38; ?>
<?php unset($__componentOriginal08b8a564843783787e0bee3357e24f38); ?>
<?php endif; ?>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<!doctype html><html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"><head><?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></head><body class="g-auth">
<div class="g-auth-shell">
    <aside class="g-auth-story"><a href="<?php echo e(route('home')); ?>" class="g-brand"><span class="g-brand-mark">g</span>growya<span class="g-brand-dot">.</span></a><div class="g-auth-story-body"><p class="g-kicker" style="color:#97c9a3">Local roots. New possibilities.</p><h2>Your next chapter<br>starts <span>right here.</span></h2><p>Discover businesses around you, connect with local expertise and give your own business a place to grow.</p><div class="g-auth-feature"><span class="g-icon-box"><?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'store']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'store']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?></span>Your own digital showroom</div><div class="g-auth-feature"><span class="g-icon-box"><?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'chat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chat']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?></span>Direct customer connections</div><div class="g-auth-feature"><span class="g-icon-box"><?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'grid']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?></span>One workspace for your business</div></div><div class="g-auth-story-foot">Discover local. Connect directly. Grow together.</div></aside>
    <section class="g-auth-content"><div class="g-auth-content-top"><div class="g-auth-mobile-brand"><a href="<?php echo e(route('home')); ?>" class="g-brand"><span class="g-brand-mark">g</span>growya<span class="g-brand-dot">.</span></a></div><a href="<?php echo e(route('public.marketplace.index')); ?>">Explore marketplace</a><a href="<?php echo e(route('home')); ?>">Back to home ↗</a></div><main id="main-content" class="g-auth-form"><p class="g-kicker">Welcome to Growya</p><?php echo e($slot); ?></main><div class="g-auth-foot">© <?php echo e(date('Y')); ?> Growya. Built for local growth.</div></section>
</div>
<?php app("livewire")->forceAssetInjection(); ?><div x-persist="<?php echo e('toast'); ?>"><?php if (isset($component)) { $__componentOriginal9e52f305f7cdd22fd6be350cf248d973 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e52f305f7cdd22fd6be350cf248d973 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::toast.group','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::toast.group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php if (isset($component)) { $__componentOriginal6e0689304ed9fe6f1f826bea0820c41b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::toast.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b)): ?>
<?php $attributes = $__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b; ?>
<?php unset($__attributesOriginal6e0689304ed9fe6f1f826bea0820c41b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e0689304ed9fe6f1f826bea0820c41b)): ?>
<?php $component = $__componentOriginal6e0689304ed9fe6f1f826bea0820c41b; ?>
<?php unset($__componentOriginal6e0689304ed9fe6f1f826bea0820c41b); ?>
<?php endif; ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e52f305f7cdd22fd6be350cf248d973)): ?>
<?php $attributes = $__attributesOriginal9e52f305f7cdd22fd6be350cf248d973; ?>
<?php unset($__attributesOriginal9e52f305f7cdd22fd6be350cf248d973); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e52f305f7cdd22fd6be350cf248d973)): ?>
<?php $component = $__componentOriginal9e52f305f7cdd22fd6be350cf248d973; ?>
<?php unset($__componentOriginal9e52f305f7cdd22fd6be350cf248d973); ?>
<?php endif; ?></div>
<?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body></html>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/layouts/auth.blade.php ENDPATH**/ ?>
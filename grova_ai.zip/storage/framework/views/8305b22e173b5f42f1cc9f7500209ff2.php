<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['value']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['value']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $tone = match ((string) $value) {
        'approved', 'active', 'paid', 'completed', 'delivered', 'confirmed' => 'green',
        'pending', 'pending_verification', 'processing', 'requested', 'unpaid' => 'amber',
        'rejected', 'cancelled', 'failed', 'inactive' => 'rose',
        default => 'blue',
    };
?>
<span class="g-badge g-tone-<?php echo e($tone); ?>"><span class="g-dot"></span><?php echo e(ucfirst(str_replace('_', ' ', (string) $value))); ?></span>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/components/growya/status.blade.php ENDPATH**/ ?>
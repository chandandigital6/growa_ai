<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name' => 'arrow-right']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name' => 'arrow-right']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $paths = [
        'home' => 'M3 10 12 3l9 7M5 9v12h5v-7h4v7h5V9',
        'store' => 'M3 10h18l-2-7H5l-2 7Zm1 0v11h16V10M9 21v-7h6v7M3 10c0 4 5 4 5 0 0 4 8 4 8 0 0 4 5 4 5 0',
        'grid' => 'M3 3h7v7H3V3Zm11 0h7v7h-7V3ZM3 14h7v7H3v-7Zm11 0h7v7h-7v-7Z',
        'box' => 'm12 3 9 5-9 5-9-5 9-5ZM3 8v9l9 5 9-5V8M12 13v9M7 5.8l9 5',
        'bag' => 'M5 7h14l2 14H3L5 7ZM8 8V6a4 4 0 0 1 8 0v2',
        'users' => 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm8-7a4 4 0 0 1 0 7.75',
        'search' => 'M21 21l-5-5M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15Z',
        'heart' => 'M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z',
        'bell' => 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Zm-8 13h4',
        'calendar' => 'M4 5h16v16H4V5ZM16 3v4M8 3v4M4 11h16m-11 4h2m2 0h2',
        'chart' => 'M3 3v18h18M7 16l4-5 4 2 6-8',
        'arrow-right' => 'M4 12h16m-6-6 6 6-6 6',
        'arrow-up-right' => 'M6 18 18 6M6 6h12v12',
        'check' => 'm5 12 4 4L19 6',
        'shield' => 'm12 3 8 3v6c0 5-8 10-8 10S4 17 4 12V6l8-3Zm-4 9 3 3 5-6',
        'clock' => 'M12 8v4l3 2m6-2a9 9 0 1 0-18 0 9 9 0 0 0 18 0Z',
        'wallet' => 'M20 8V5H4a2 2 0 0 0 0 4h17v11H4a2 2 0 0 1-2-2V7m19 6h-5v4h5',
        'chat' => 'M21 11a9 9 0 0 1-9 9H3l2-5a9 9 0 1 1 16-4Zm-14 0h1m3 0h1m3 0h1',
        'star' => 'm12 3 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1 3-6Z',
        'settings' => 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-3-5h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Z',
        'tag' => 'M3 3h8l10 10-8 8L3 11V3Zm4 4h.01',
        'photo' => 'M3 3h18v18H3V3Zm0 14 6-6 4 4 3-3 5 5M8 7h.01',
        'link' => 'm10 13 4-4m-6 6-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m2 3 2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0',
        'truck' => 'M1 3h14v14H1V3Zm14 5h4l4 4v5h-8m-9 4a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm13 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z',
        'return' => 'M9 4 3 10l6 6M3 10h12a6 6 0 0 1 0 12',
        'plus' => 'M12 5v14M5 12h14',
        'menu' => 'M4 6h16M4 12h16M4 18h16',
        'close' => 'm6 6 12 12M6 18 18 6',
        'sun' => 'M12 3V1m0 22v-2M3 12H1m22 0h-2M5 5 3 3m18 18-2-2M5 19l-2 2M21 3l-2 2m-7 2a5 5 0 1 0 0 10 5 5 0 0 0 0-10Z',
        'moon' => 'M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z',
        'pin' => 'M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Zm-8-3a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z',
        'logout' => 'M9 4H3v16h6m6-4 4-4-4-4M8 12h11',
        'globe' => 'M21 12a9 9 0 1 0-18 0 9 9 0 0 0 18 0ZM3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z',
        'sparkles' => 'm12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z',
    ];
?>
<svg <?php echo e($attributes->merge(['class' => 'g-icon'])); ?> viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="<?php echo e($paths[$name] ?? $paths['grid']); ?>" /></svg>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/components/growya/icon.blade.php ENDPATH**/ ?>
<?php if (! $__env->hasRenderedOnce('cb73511e-9627-4370-8ee1-3b222f7c33f2')): $__env->markAsRenderedOnce('cb73511e-9627-4370-8ee1-3b222f7c33f2'); ?>
<meta name="theme-color" content="#123c32">
<link rel="icon" href="<?php echo e(asset('growya-ui/favicon.svg')); ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?php echo e(asset('growya-ui/theme.css')); ?>?v=20261013">
<script src="<?php echo e(asset('growya-ui/theme.js')); ?>?v=20261013" defer></script>
<?php endif; ?>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/partials/growya-assets.blade.php ENDPATH**/ ?>
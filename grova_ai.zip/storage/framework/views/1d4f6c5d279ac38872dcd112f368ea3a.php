<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'value', 'note' => null, 'icon' => 'chart', 'tone' => 'green', 'href' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'value', 'note' => null, 'icon' => 'chart', 'tone' => 'green', 'href' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<article class="g-stat">
    <div class="g-stat-top"><span class="g-muted"><?php echo e($label); ?></span><span class="g-icon-box g-tone-<?php echo e($tone); ?>"><?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => $icon]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?></span></div>
    <p class="g-stat-value"><?php echo e($value); ?></p>
    <div class="g-stat-bottom"><span><?php echo e($note); ?></span><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($href): ?><a href="<?php echo e($href); ?>" aria-label="Open <?php echo e($label); ?>"><?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'arrow-up-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-up-right']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
</article>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/components/growya/stat.blade.php ENDPATH**/ ?>
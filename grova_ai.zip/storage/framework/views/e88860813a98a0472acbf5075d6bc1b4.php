<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>
    <?php echo e(filled($title ?? null) ? $title.' - '.config('app.name', 'grova_ai') : config('app.name', 'grova_ai')); ?>

</title>





<?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php echo $__env->make('partials.growya-assets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo app('flux')->fluxAppearance(); ?>

<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/partials/head.blade.php ENDPATH**/ ?>
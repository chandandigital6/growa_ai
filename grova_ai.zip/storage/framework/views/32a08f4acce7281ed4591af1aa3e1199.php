<footer class="g-site-footer"><div class="g-container"><div class="g-site-footer-grid">
    <div><a href="<?php echo e(route('home')); ?>" class="g-brand"><span class="g-brand-mark">g</span>growya<span class="g-brand-dot">.</span></a><p>Great local businesses deserve to be discovered. Explore products, connect with service providers and bring your own business online.</p><span class="g-badge g-tone-green"><?php if (isset($component)) { $__componentOriginal06bb700667f9b27cf96f9e91866835d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06bb700667f9b27cf96f9e91866835d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.growya.icon','data' => ['name' => 'pin','style' => 'width:12px;height:12px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('growya.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pin','style' => 'width:12px;height:12px']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $attributes = $__attributesOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__attributesOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06bb700667f9b27cf96f9e91866835d0)): ?>
<?php $component = $__componentOriginal06bb700667f9b27cf96f9e91866835d0; ?>
<?php unset($__componentOriginal06bb700667f9b27cf96f9e91866835d0); ?>
<?php endif; ?>Built for local growth</span></div>
    <div><h3>Explore Growya</h3><nav aria-label="Explore links"><a href="<?php echo e(route('public.marketplace.index')); ?>">Marketplace</a><a href="<?php echo e(route('home')); ?>#products">Products</a><a href="<?php echo e(route('home')); ?>#services">Services</a><a href="<?php echo e(route('public.offers.index')); ?>">Offers & promotions</a><a href="<?php echo e(route('public.search.index')); ?>">Search listings</a></nav></div>
    <div><h3>Your next chapter</h3><nav aria-label="Account links"><a href="<?php echo e(auth()->check() ? route('businesses.create') : route('register')); ?>">Create your showroom</a><a href="<?php echo e(auth()->check() ? route('dashboard') : route('login')); ?>"><?php echo e(auth()->check() ? 'Your dashboard' : 'Log in to Growya'); ?></a><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?><a href="<?php echo e(route('growya.orders.mine')); ?>">Your orders</a><a href="<?php echo e(route('public.business.following')); ?>">Following</a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><a href="<?php echo e(route('home')); ?>#about">For businesses</a></nav></div>
</div><div class="g-site-footer-bottom"><span>© <?php echo e(date('Y')); ?> Growya. All rights reserved.</span><span>Discover local. Connect directly. Grow together.</span></div></div></footer>
<?php /**PATH D:\growya-static-tailwind\grova_ai\resources\views/public/partials/site-footer.blade.php ENDPATH**/ ?>